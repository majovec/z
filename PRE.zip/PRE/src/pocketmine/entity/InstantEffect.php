<?php



namespace pocketmine\entity;

class InstantEffect extends Effect{

}