<?php



namespace pocketmine\entity;


abstract class Vehicle extends Entity implements Rideable{

}