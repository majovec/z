<?php



namespace pocketmine\entity;


interface Explosive{

	public function explode();
}