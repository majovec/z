<?php



namespace pocketmine\entity;


interface Ageable{
	public function isBaby();
}