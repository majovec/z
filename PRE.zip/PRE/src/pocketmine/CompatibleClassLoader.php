<?php



namespace pocketmine;

class CompatibleClassLoader extends \BaseClassLoader{

}