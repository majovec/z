<?php



namespace pocketmine\event;

interface Listener{

}